<?php

class LessonModelUpyun extends JModelLegacy {

}