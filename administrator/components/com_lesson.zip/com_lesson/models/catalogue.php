<?php

class LessonModelCatalogue extends JModelLegacy {

	
}