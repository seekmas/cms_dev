<?php

class LessonViewCatalogue extends JViewLegacy
{
	public function display( $tpl = null)
	{
		parent::display( $tpl = null);
	}
}