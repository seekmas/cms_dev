<?php
/**
* @copyright	Copyright (C) 2009 - 2009 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package		PayPlans
* @subpackage	Modules
* @contact 		shyam@readybytes.in
*/
if(defined('_JEXEC')===false) die(); ?>
<div class="pp-migrate-post-thanks">
<?php echo XiText::_('PLG_PAYPLANS_SAMPLE_THANKS_MESSAGE');?>
</div>